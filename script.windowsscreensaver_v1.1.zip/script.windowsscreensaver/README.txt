This is a python script screensaver. When activated it will call upon the
current windows system screensaver. So you will be able to use one of the
many screensavers out there. Aquariums, Fireplaces, Starfields now all
within your Windows XBMC-Mediacenter.

This script will probably never make it in the standard repository, as it
is relying on an external c++ program written by me, to do its work.
For the wary, the source is included. Please check it and compile it
yourself or trust my word that it is free of malicious code.
To get the addon running you'll have to install it from zip.

The script code itself is mostly taken from an example by derspere.
https://github.com/xbmc/xbmc/pull/1072
Without his and garbears work to enable python script screensavers
within XBMC this would not have been possible.

Lastly I would like to thank the XBMC-Team for what is IMHO simply
the greatest media center. :)





  